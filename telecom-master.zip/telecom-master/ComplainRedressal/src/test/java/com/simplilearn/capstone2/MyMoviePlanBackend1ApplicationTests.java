package com.simplilearn.capstone2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMoviePlanBackend1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
